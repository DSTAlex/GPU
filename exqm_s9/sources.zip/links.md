Links
=====

__shfl_down_sync       : https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html#warp-shuffle-functions
thrust::transform      : https://nvidia.github.io/cccl/thrust/api/function_group__transformations_1gacbd546527729f24f27dc44e34a5b8f73.html
thrust::exclusive_scan : https://nvidia.github.io/cccl/thrust/api/function_group__prefixsums_1gad57155adfbf01ba6660839aafe16ad71.html
thrust::scatter_if     : https://nvidia.github.io/cccl/thrust/api/function_group__scattering_1ga72c5ec1e36f08a1bd7b4e0b20e7e906d.html
