Ce tp a ete realiser par DI SANTO Alexandre et ROYER Julia


Use ./compare_exo1.sh to run exo1_2 et exo1_3 et comparer les temps d'execution.

Use ./compare_exo2.sh to run exo2_1 et exo2_2 et comparer les temps d'execution.


Ces scriptes compilent les exercices, les executent puis suppriment les binaires.